# Thunderbird MultiSend Extension

A Thunderbird extension to partition and send a single body of text to multiple recipients.
